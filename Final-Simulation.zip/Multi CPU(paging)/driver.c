#include "queue.h"
#include "sim_structs.h"
#include<stdio.h>
#include<stdlib.h>
#include<stddef.h>
#include<string.h>
#include<time.h>

//CPU modules
void CPU(struct Queue* readyQ);
void Decode(unsigned int instruction, struct Decode_block* block, struct CPU* CPU);
void Dispatcher(struct CPU* CPU, const struct PCB* job);
void Execute(struct CPU* CPU, struct Decode_block* block);
unsigned int Fetch(struct CPU* CPU);
unsigned int GenAddress(unsigned int address);
void Loader(const char* file_name, struct Queue* newQ);
unsigned int* Memory(const unsigned int value, struct PCB* job, const char* location, const char* mode);
const unsigned int* Scheduler(struct Queue* newQ, struct Queue* readyQ);

//execution controllers
void Execute_B_I_FORM(struct CPU* CPU, struct Decode_block* block);
void Execute_JUMP_FORM(struct CPU* CPU, struct Decode_block* block);
void Execute_IO_FORM(struct CPU* CPU, struct Decode_block* block);
void Execute_ART_FORM(struct CPU* CPU, struct Decode_block* block);

//helper modules
void Decode_B_I_FORM(unsigned int instruction, struct Decode_block* block, struct CPU* CPU);
void Decode_JUMP_FORM(unsigned int instruction, struct Decode_block* block, struct CPU* CPU);
void Decode_IO_FORM(unsigned int instruction, struct Decode_block* block, struct CPU* CPU);
void Decode_ART_FORM(unsigned int instruction, struct Decode_block* block, struct CPU* CPU);
void StripCard(const char* card, struct Queue* newQ);

//opcode functions
void op_RD(struct CPU* CPU, struct Decode_block* block);
void op_WR(struct CPU* CPU, struct Decode_block* block);
void op_ST(struct CPU* CPU, struct Decode_block* block);
void op_LW(struct CPU* CPU, struct Decode_block* block);
void op_MOV(struct CPU* CPU, struct Decode_block* block);
void op_ADD(struct CPU* CPU, struct Decode_block* block);
void op_SUB(struct CPU* CPU, struct Decode_block* block);
void op_MUL(struct CPU* CPU, struct Decode_block* block);
void op_DIV(struct CPU* CPU, struct Decode_block* block);
void op_AND(struct CPU* CPU, struct Decode_block* block);
void op_OR(struct CPU* CPU, struct Decode_block* block);
void op_MOVI(struct CPU* CPU, struct Decode_block* block);
void op_ADDI(struct CPU* CPU, struct Decode_block* block);
void op_MULI(struct CPU* CPU, struct Decode_block* block);
void op_DIVI(struct CPU* CPU, struct Decode_block* block);
void op_LDI(struct CPU* CPU, struct Decode_block* block);
void op_SLT(struct CPU* CPU, struct Decode_block* block);
void op_SLTI(struct CPU* CPU, struct Decode_block* block);
void op_HLT(struct CPU* CPU, struct Decode_block* block);
void op_NOP(struct CPU* CPU, struct Decode_block* block);
void op_JMP(struct CPU* CPU, struct Decode_block* block);
void op_BEQ(struct CPU* CPU, struct Decode_block* block);
void op_BNE(struct CPU* CPU, struct Decode_block* block);
void op_BEZ(struct CPU* CPU, struct Decode_block* block);
void op_BNZ(struct CPU* CPU, struct Decode_block* block);
void op_BGZ(struct CPU* CPU, struct Decode_block* block);
void op_BLZ(struct CPU* CPU, struct Decode_block* block);

//constants
const unsigned int NUM_OF_CPUS = 4;
const unsigned int PAGE_SIZE = 4;

int main(){
	//start timer 
	clock_t totalStart, totalEnd;
	totalStart = clock();

	//create and allocate memory to queue pointers
	struct Queue* newQ = malloc(sizeof(struct Queue));
	struct Queue* waitQ = malloc(sizeof(struct Queue));
	struct Queue* readyQ = malloc(sizeof(struct Queue));
	
	//load Program-File.txt into disk and create jobs
  	Loader("Program-File.txt", newQ);
  	
  	//loop until all queues are empty
  	while((newQ->head != NULL) || (readyQ->head != NULL) || (waitQ->head != NULL)){
    	Scheduler(newQ, readyQ);
    	CPU(readyQ);
    	//WaitForInterrupt();
  	}
  	
  	//stop total timer and output total execution time
  	totalEnd = clock();
  	printf("Total elapsed time for execution was %u.\n", totalEnd - totalStart);
  	exit(0);
}

void CPU(struct Queue* readyQ){
	//start job timer
	//clock_t jobStart, jobEnd;
	//jobStart = clock();

  	//CPU and Decoding block set up
  	struct CPU* CPU_arr[NUM_OF_CPUS];
  	struct Decode_block* block_arr[NUM_OF_CPUS];
  	
  	//pointers to current CPU and decode block to be modified
  	struct CPU** next_CPU = CPU_arr;
  	struct Decode_block** next_block = block_arr;
  	
  	//boolean to check if all jobs finished
  	unsigned int finished = 0;
  	
  	//set each CPU info for next job if one is available
  	struct PCB* next_queued_job = readyQ->head;
  	for(int count = 0; count != NUM_OF_CPUS; ++count){
  		if(next_queued_job != NULL){
  			*next_CPU = malloc(sizeof(struct CPU));
  			Dispatcher(*next_CPU, next_queued_job);
  			*next_block = malloc(sizeof(struct Decode_block));
  			next_queued_job = next_queued_job->next_job;
  		}
  		else{
  			next_CPU = NULL;
  			next_block = NULL;
  		}
  		++next_CPU;
  		++next_block;
  	}
  	
  	//reset CPU and block pointers
  	next_CPU = CPU_arr;
  	next_block = block_arr;
  		
  	//run execution loop
  	do{
  		//for each CPU with a job, get next instruction
  		for(int count = 0; count != NUM_OF_CPUS; ++count){
  			if(*next_CPU != NULL)
  				(*next_CPU)->CPU_registers.i_register = Fetch(*next_CPU);
  			++next_CPU;
  		}
  		
  		//reset CPU pointer
  		next_CPU = CPU_arr;
  		
  		//for each CPU with a job, decode next instruction
  		for(int count = 0; count != NUM_OF_CPUS; ++count){
  			if(*next_CPU != NULL)
  				Decode((*next_CPU)->CPU_registers.i_register, *next_block, *next_CPU);
  				
  			++next_CPU;
  			++next_block;
  		}
  		
  		//reset CPU and block pointers
  		next_CPU = CPU_arr;
  		next_block = block_arr;
  		
  		//for each CPU with a job, execute next instruction;
  		for(int count = 0; count != NUM_OF_CPUS; ++count){
  			if(*next_CPU != NULL){
  				//execute instuction
  				Execute(*next_CPU, *next_block);
  				//increment program counter
  				++((*next_CPU)->program_counter);
  			}
  			++next_CPU;
  			++next_block;
  		}
  		//reset CPU and block pointers
  		next_CPU = CPU_arr;
  		next_block = block_arr;
  		
  		//if jobs still need to finish, set flag to 0
  		//if a job is done, free memory and mark NULL
  		finished = 1;
  		for(int count = 0; count != NUM_OF_CPUS; ++count){
  			if(*next_CPU != NULL){
  				if((*next_CPU)->HLT_mon){
  					//write output of job
  					printf("Job %u results\n", (*next_CPU)->job->jobID);
  					for(unsigned int i = (*next_CPU)->job->out_buff_pos; i != (*next_CPU)->job->temp_buff_pos; ++i)
  						printf("%u\n", *(Memory(GenAddress(i), (*next_CPU)->job, "RAM", "r")));
  					printf("\n");
  					//clear memory frames
  					Memory(0, (*next_CPU)->job, "RAM", "clear");
  					//clear job from ready queue
  					DeleteJob(readyQ, (*next_CPU)->currentJobID);
  					//free CPU and block data
  					free(*next_CPU);
  					*next_CPU = NULL;
  					free(*next_block);
  					*next_block = NULL;
  				}
  				else
  					finished = 0;
  			}
  			++next_CPU;
  			++next_block;
  		}
  		//reset CPU and block pointers
  		next_CPU = CPU_arr;
  		next_block = block_arr;
  	}while(!finished);
  	//print job info
  	//jobEnd = clock();
  	//printf("Running Job #%u, Execution Time %ums\n", head->jobID, jobEnd - jobStart);
  	
  	//OUTPUT SCAN
  	//printf("Job %u results\n", readyQ->head->jobID);
  	//for(int i = readyQ->head->out_buff_pos; i != readyQ->head->temp_buff_pos; ++i)
  	//	printf("%u\n", *(Memory(GenAddress(i), readyQ->head, "RAM", "r")));
	//printf("\n");
}

void Decode(unsigned int instruction, struct Decode_block* block, struct CPU* CPU){
  //parse format and decode further
  unsigned int form = instruction & FORM_MASK;
  if(form == B_I_FORM){
    block->format = B_I_FORM;
    Decode_B_I_FORM(instruction, block, CPU);
  }
  else if(form == JUMP_FORM){
    block->format = JUMP_FORM;
    Decode_JUMP_FORM(instruction, block, CPU);
  }
  else if(form == IO_FORM){
    block->format = IO_FORM;
    Decode_IO_FORM(instruction, block, CPU);
  }
  else{
    block->format = ART_FORM;
    Decode_ART_FORM(instruction, block, CPU);
  }
}

void Decode_B_I_FORM(unsigned int instruction, struct Decode_block* block, struct CPU* CPU){
  //parse opcode
  unsigned int code = instruction & OPCODE_MASK;
  if(code == ST)
    block->opcode = ST;
  else if(code == LW)
    block->opcode = LW;
  else if(code == MOVI)
    block->opcode = MOVI;
  else if(code == ADDI)
    block->opcode = ADDI;
  else if(code == MULI)
    block->opcode = MULI;
  else if(code == DIVI)
    block->opcode = DIVI;
  else if(code == LDI)
    block->opcode = LDI;
  else if(code == SLTI)
    block->opcode = SLTI;
  else if(code == BEQ)
    block->opcode = BEQ;
  else if(code == BNE)
    block->opcode = BNE;
  else if(code == BEZ)
    block->opcode = BEZ;
  else if(code == BNZ)
    block->opcode = BNZ;
  else if(code == BGZ)
    block->opcode = BGZ;
  else
    block->opcode = BLZ;

  //B-reg
  block->reg1 = CPU->CPU_registers.reg_set;
  block->reg1 += ((instruction & REG1_MASK) >> REG1_RSHIFT);

  //D-reg
  block->reg2 = CPU->CPU_registers.reg_set;
  block->reg2 += ((instruction & REG2_MASK) >> REG2_RSHIFT);

  //reg3
  block->reg3 = NULL;
  
  //address in words away from current program_counter
  block->address = (instruction & B_I_ADDRESS);
}

void Decode_JUMP_FORM(unsigned int instruction, struct Decode_block* block, struct CPU* CPU){
  //parse opcode
  unsigned int code = instruction & OPCODE_MASK;
  if(code == HLT)
    block->opcode = HLT;
  else
    block->opcode = JMP;

  //reg1 unused
  block->reg1 = NULL;

  //reg2 unused
  block->reg2 = NULL;

  //reg3 unused
  block->reg3 = NULL;

  //address of jump
  block->address = instruction & JUMP_ADDRESS;
}

void Decode_IO_FORM(unsigned int instruction, struct Decode_block* block, struct CPU* CPU){
  //parse opcode
  unsigned int code = instruction & OPCODE_MASK;
  if(code == WR)
    block->opcode = WR;
  else
    block->opcode = RD;

  //Reg1
  block->reg1 = CPU->CPU_registers.reg_set;
  block->reg1 += ((instruction & REG1_MASK) >> REG1_RSHIFT);

  //Reg2
  block->reg2 = CPU->CPU_registers.reg_set;
  block->reg2 += ((instruction & REG2_MASK) >> REG2_RSHIFT);

  //reg3 unused
  block->reg3 = NULL;

  //address in words away from current program_counter
  block->address = (instruction & IO_ADDRESS);
}

void Decode_ART_FORM(unsigned int instruction, struct Decode_block* block, struct CPU* CPU){
  //parse opcode
  unsigned int code = instruction & OPCODE_MASK;
  if(code == MOV)
      block->opcode = MOV;
    else if(code == ADD)
      block->opcode = ADD;
    else if(code == SUB)
      block->opcode = SUB;
    else if(code == MUL)
      block->opcode = MUL;
    else if(code == DIV)
      block->opcode = DIV;
    else if(code == AND)
      block->opcode = AND;
    else if(code == OR)
      block->opcode = OR;
    else
      block->opcode = SLT;

  //S-reg 1
  block->reg1 = CPU->CPU_registers.reg_set;
  block->reg1 += ((instruction & REG1_MASK) >> REG1_RSHIFT);

  //S-reg 2
  block->reg2 = CPU->CPU_registers.reg_set;
  block->reg2 += ((instruction & REG2_MASK) >> REG2_RSHIFT);

  //D-reg 3
  block->reg3 = CPU->CPU_registers.reg_set;
  block->reg3 += ((instruction & REG3_MASK) >> REG3_RSHIFT);
}

void Dispatcher(struct CPU* CPU_ptr, const struct PCB* job){
  CPU_ptr->job = job;
  CPU_ptr->currentJobID = job->jobID;
  CPU_ptr->program_counter = job->program_counter;
  
  //reset registers
  //for(int i = 0; i != 16; ++i){
  //	CPU_ptr->CPU_registers.reg_set[i].data = 0;
  //	CPU_ptr->CPU_registers.reg_set[i].isData = 1;
  //	CPU_ptr->CPU_registers.reg_set[i].isAddress = 0;
  //}
}

void Execute(struct CPU* CPU, struct Decode_block* block){
  if(block->format == B_I_FORM)
    Execute_B_I_FORM(CPU, block);
  else if(block->format == JUMP_FORM)
    Execute_JUMP_FORM(CPU, block);
  else if(block->format == IO_FORM)
    Execute_IO_FORM(CPU, block);
  else
    Execute_ART_FORM(CPU, block);
}

unsigned int Fetch(struct CPU* CPU){
	//call memory using the correct physical address and return it
	return *(Memory(GenAddress(CPU->program_counter), CPU->job, "RAM", "r"));;
}

unsigned int GenAddress(unsigned int address){
	//value returned from instruction fetch
	unsigned int val;
	//get page number
	val = (address / PAGE_SIZE);
	//shift bits to include offset
	val = (val << 2);
	//OR in the offset
	val = (val | (address % PAGE_SIZE));
	return val;
}

void Loader(const char* file_name, struct Queue* newQ){
  //open program file
  FILE* file_ptr = fopen(file_name, "r");

  //string to hold next line
  char next_line[30];
  
  while(!feof(file_ptr)){
    //parse next line
    fgets(next_line, 30, file_ptr);
    
    //check line for control card
    if(next_line[1] != 'x'){
      StripCard(next_line, newQ);
    }
    else
      Memory(strtoul(next_line, NULL, 16), NULL, "Disk", "w");
  }

  //close Program-File
  fclose(file_ptr);
}

unsigned int* Memory(const unsigned int value, struct PCB* job, const char* location, const char* mode){
  static unsigned int Disk[2048];
  static unsigned int RAM[1024];
  static unsigned int frameTable[256];

  //maintains the next spot in which a value is to be written into Disk
  static unsigned int nextWriteDisk = 0;
  //cursor for frameTable
  static unsigned int tableCursor = 0;

  //return value
  unsigned int* datum_location;
  
  //check to see if Disk or RAM is to be accessed, the if its a read or write request
  if(location == "Disk"){

    //check for NULL mode (asks for first spot, used only by first init)
    if(mode != "wNew"){

      //check for read or write request
      if(mode == "r"){
		datum_location = Disk + value;
      }
      else{
		datum_location = Disk + nextWriteDisk;
		Disk[nextWriteDisk] = value;
		nextWriteDisk = (nextWriteDisk + 1) % sizeof(Disk);
      }
    }
    else
      	datum_location = Disk;
  }
  else{
  	if(mode != "clear"){
    	if(mode == "r"){
    		//check the desired page is in RAM
    		if(job->table[(value & PAGE_MASK) >> 2].valid){
    			//page is in RAM, fetch frame number, scale it to correct space in RAM, and add the offset
    			datum_location = RAM + ((job->table[(value & PAGE_MASK) >> 2].frameNum * 4) + (value & OFF_MASK));
    		}
    		else{
    			//page is not in RAM, call Memory again to place correct page into RAM then get location
    			Memory((value & PAGE_MASK) >> 2, job, "RAM", "w");
    			datum_location = RAM + ((job->table[(value & PAGE_MASK) >> 2].frameNum * 4) + (value & OFF_MASK));
    		}
    	}
    	else{
    		//check if the next frame is free
      		if(frameTable[tableCursor] != 1){
      			//write the contents of the page into the free frame
      			for(int i = tableCursor * PAGE_SIZE; i != (tableCursor * PAGE_SIZE) + PAGE_SIZE; ++i)
      				RAM[i] = *(job->program_disk_start + ((value * PAGE_SIZE) + (i % PAGE_SIZE)));
      		}
      		//otherwise, find a free frame
      		else{
      			unsigned int nextFrame = tableCursor;
      			while(frameTable[nextFrame] == 1){
      				nextFrame = (nextFrame + 1) % 256;
      			}
      			tableCursor = nextFrame;
      		
      			//write contents of the page into the free frame
      			for(int i = tableCursor * PAGE_SIZE; i != (tableCursor * PAGE_SIZE) + PAGE_SIZE; ++i){
      				RAM[i] = *(job->program_disk_start + ((value * PAGE_SIZE) + (i % PAGE_SIZE)));
      			}
      		}
      		
      		//set page table in PCB to show page is in RAM
      		job->table[value].frameNum = tableCursor;
      		job->table[value].valid = 1;
      		
      		//update frame table and increment cursor
      		frameTable[tableCursor] = 1;
      		++tableCursor;
    	}
    }
    else{
    	//for each page, if allocated space, mark it clear
    	for(unsigned int i = 0; i != 20; ++i)
    		if(job->table[i].valid)
    			frameTable[job->table[i].frameNum] = 0;
    }
  }
  
  return datum_location;
}

const unsigned int* Scheduler(struct Queue* newQ, struct Queue* readyQ){
	//until there is a job for each CPU or there are no more jobs
	//load jobs from newQ into RAM and place them on readyQ
	while(newQ->size != 0){
		//place the first 4 pages of the head of newQ into RAM
  		for(int count = 0; count != 4; ++count){
  			Memory(count, newQ->head, "RAM", "w");
  		}
  		
  		//move job from newQ to readyQ (non-priority)
  		MoveJob(newQ, readyQ);
  		//move job from newQ to readyQ (priority)
  		//MoveHighestPJob(newQ, readyQ);
	}	
}

void StripCard(const char* card, struct Queue* newQ){
  char* card_cursor;
  
  //if JOB, create PCB for process
  if((card_cursor = strstr(card, "JOB")) != NULL){
  	//temp pointer for old tail
  	struct PCB* old_tail = newQ->tail;
  	
    //make new PCB
    struct PCB* new_job = malloc(sizeof(struct PCB));
    
    //record card values in PCB
    unsigned int reads = 0;
    card_cursor += 4;
    while(reads < 3){
      if(reads == 0)
		new_job->jobID = strtoul(card_cursor, &card_cursor, 16);
      else if(reads == 1)
		new_job->jobInstructionSize = strtoul(card_cursor, &card_cursor, 16);
      else
		new_job->jobPriority = strtoul(card_cursor, &card_cursor, 16);
      ++reads;
    }
    
    //add job to newQ
    AddJob(newQ, new_job);
    
    //if there was no older job, set default values
    if(old_tail == NULL){
    	newQ->tail->program_disk_start = Memory(0, NULL, "Disk", "wNew");
    	newQ->tail->program_counter = 0;
    }
    //else, set program pointers based on older job
    else{
    	newQ->tail->program_disk_start = old_tail->program_disk_start + old_tail->jobTotalSize;
    	newQ->tail->program_counter = 0;
    }
  }

  //if Data, fill in buffer info
  else if((card_cursor = strstr(card, "Data")) != NULL){
    //record card values in PCB
    unsigned int reads = 0;
    card_cursor += 5;
    while(reads < 3){
      if(reads == 0)
	newQ->tail->inBuffSize = strtoul(card_cursor, &card_cursor, 16);
      else if(reads == 1)
	newQ->tail->outBuffSize = strtoul(card_cursor, &card_cursor, 16);
      else
	newQ->tail->tempBuffSize = strtoul(card_cursor, &card_cursor, 16);
      ++reads;
    }

    //set buffer pointers and total size
    newQ->tail->jobTotalSize = newQ->tail->jobInstructionSize + newQ->tail->inBuffSize + newQ->tail->outBuffSize + newQ->tail->tempBuffSize;
    newQ->tail->in_buff_pos = newQ->tail->jobInstructionSize;
    newQ->tail->out_buff_pos = newQ->tail->in_buff_pos + newQ->tail->inBuffSize;
    newQ->tail->temp_buff_pos = newQ->tail->out_buff_pos + newQ->tail->outBuffSize;
  }

  //if END, do nothing
  else
    ;
}

//Execution and Opcode implementations
void Execute_B_I_FORM(struct CPU* CPU, struct Decode_block* block){
  if(block->opcode == ST)
    op_ST(CPU, block);
  else if(block->opcode == LW)
    op_LW(CPU, block);
  else if(block->opcode == MOVI)
    op_MOVI(CPU, block);
  else if(block->opcode == ADDI)
    op_ADDI(CPU, block);
  else if(block->opcode == MULI)
    op_MULI(CPU, block);
  else if(block->opcode == DIVI)
    op_DIVI(CPU, block);
  else if(block->opcode == LDI)
    op_LDI(CPU, block);
  else if(block->opcode == SLTI)
    op_SLTI(CPU, block);
  else if(block->opcode == BEQ)
    op_BEQ(CPU, block);
  else if(block->opcode == BNE)
    op_BNE(CPU, block);
  else if(block->opcode == BEZ)
    op_BEZ(CPU, block);
  else if(block->opcode == BNZ)
    op_BNZ(CPU, block);
  else if(block->opcode == BGZ)
    op_BGZ(CPU, block);
  else
    op_BLZ(CPU, block);
}

void Execute_JUMP_FORM(struct CPU* CPU, struct Decode_block* block){
  if(block->opcode == HLT)
    op_HLT(CPU, block);
  else
    ;
}

void Execute_IO_FORM(struct CPU* CPU, struct Decode_block* block){
  if(block->opcode == WR)
    op_WR(CPU, block);
  else
    op_RD(CPU, block);
}

void Execute_ART_FORM(struct CPU* CPU, struct Decode_block* block){
  if(block->opcode == MOV)
    op_MOV(CPU, block);
  else if(block->opcode == ADD)
    op_ADD(CPU, block);
  else if(block->opcode == SUB)
    op_SUB(CPU, block);
  else if(block->opcode == MUL)
    op_MUL(CPU, block);
  else if(block->opcode == DIV)
    op_DIV(CPU, block);
  else if(block->opcode == AND)
    op_AND(CPU, block);
  else if(block->opcode == OR)
    op_OR(CPU, block);
  else
    op_SLT(CPU, block);
}

void op_RD(struct CPU* CPU, struct Decode_block* block){
  //store the contents of reg2 into reg1
  if(block->address == 0){
  	if(block->reg2->isAddress)
  		block->reg1->data = *(Memory(GenAddress(block->reg2->data), CPU->job, "RAM", "r"));
  	else
  		block->reg1->data = block->reg2->data;
  }
    
  //store data at start of program + address offset int reg1
  else
    block->reg1->data = *(Memory(GenAddress(block->address / 4), CPU->job, "RAM", "r"));
    
  //set reg1 markers
  block->reg1->isData = 1;
  block->reg1->isAddress = 0;
}

void op_WR(struct CPU* CPU, struct Decode_block* block){
	if(block->address == 0)
		*(Memory((block->reg2->data), CPU->job, "RAM", "r")) = block->reg1->data;
	else
		*(Memory(GenAddress(block->address / 4), CPU->job, "RAM", "r")) = block->reg1->data;
}

void op_ST(struct CPU* CPU, struct Decode_block* block){
	//store reg1 data at address pointed to by reg2 address
	*(Memory(GenAddress(block->reg2->data), CPU->job, "RAM", "r")) = block->reg1->data;
}

void op_LW(struct CPU* CPU, struct Decode_block* block){
	block->reg2->data = *(Memory(GenAddress(block->reg1->data + block->address), CPU->job, "RAM", "r"));
	block->reg2->isData = 1;
	block->reg2->isAddress = 0;
}

void op_MOV(struct CPU* CPU, struct Decode_block* block){
	block->reg1->data = block->reg2->data;
	block->reg1->isData = block->reg2->isData;
	block->reg1->isAddress = block->reg2->isAddress;
	/*
	//reg1 and reg2 are both 0 which means S-reg is accumulator
	if(((CPU->CPU_registers.i_register & REG1_MASK) == 0) && ((CPU->CPU_registers.i_register & REG2_MASK) == 0))
		block->reg3->data = block->reg2->data;
	else if(((CPU->CPU_registers.i_register & REG1_MASK) != 0) && ((CPU->CPU_registers.i_register & REG2_MASK) == 0))
		block->reg3->data = block->reg1->data;
	else
		block->reg3->data = block->reg2->data;
	*/
}

void op_ADD(struct CPU* CPU, struct Decode_block* block){
	block->reg3->data = block->reg1->data + block->reg2->data;
}

void op_SUB(struct CPU* CPU, struct Decode_block* block){
}

void op_MUL(struct CPU* CPU, struct Decode_block* block){
}

void op_DIV(struct CPU* CPU, struct Decode_block* block){
	block->reg3->data = (block->reg1->data / block->reg2->data);
}

void op_AND(struct CPU* CPU, struct Decode_block* block){
}

void op_OR(struct CPU* CPU, struct Decode_block* block){
}

void op_MOVI(struct CPU* CPU, struct Decode_block* block){
  if((block->address == 0) && ((CPU->CPU_registers.i_register & REG1_MASK) == 0)){
    block->reg2->data = 0;
    block->reg2->isData = 1;
  	block->reg2->isAddress = 0;
  }
  else if((block->address == 0) && ((CPU->CPU_registers.i_register & REG1_MASK) != 0)){
  	if(block->reg1->isData){
  		block->reg2->data = block->reg1->data;
  		block->reg2->isData = 1;
  		block->reg2->isAddress = 0;
  	}
  	else{
  		block->reg2->data = block->reg1->data;
  		block->reg2->isData = 0;
  		block->reg2->isAddress = 1;
  	}
  }
  else
  	block->reg2->data = block->address;
}

void op_ADDI(struct CPU* CPU, struct Decode_block* block){
	if(block->reg2->isData){
		block->reg2->data += block->address;
	}
	else
		block->reg2->data += (block->address / 4);
}

void op_MULI(struct CPU* CPU, struct Decode_block* block){
}

void op_DIVI(struct CPU* CPU, struct Decode_block* block){
}

void op_LDI(struct CPU* CPU, struct Decode_block* block){
	if(block->address == 0){
		if(block->reg1->isData){
  			block->reg2->data = block->reg1->data;
  			block->reg2->isData = 1;
  			block->reg2->isAddress = 0;
  		}
  		else{
  			block->reg2->data = block->reg1->data;
  			block->reg2->isData = 0;
  			block->reg2->isAddress = 1;
  		}
  	}
  	else{
  		block->reg2->data = (block->address / 4);
  		block->reg2->isData = 0;
  		block->reg2->isAddress = 1;
  	}
}

void op_SLT(struct CPU* CPU, struct Decode_block* block){
	unsigned int boolean;
	if(block->reg1->isData){
		if(block->reg2->isData)
			boolean = (block->reg1->data < block->reg2->data);
		else
			boolean = (block->reg1->data < *(Memory(GenAddress(block->reg2->data), CPU->job, "RAM", "r")));
	}
	else{
		if(block->reg2->isData)
			boolean = *(Memory(GenAddress(block->reg1->data), CPU->job, "RAM", "r")) < block->reg2->data;
		else
			boolean = *(Memory(GenAddress(block->reg1->data), CPU->job, "RAM", "r")) < *(Memory(GenAddress(block->reg2->data), CPU->job, "RAM", "r"));
	}
	block->reg3->data = boolean;
	block->reg3->isData = 1;
	block->reg3->isAddress = 0;
}

void op_SLTI(struct CPU* CPU, struct Decode_block* block){
}

void op_HLT(struct CPU* CPU, struct Decode_block* block){
	CPU->HLT_mon = 1;
}

void op_NOP(struct CPU* CPU, struct Decode_block* block){
}

void op_JMP(struct CPU* CPU, struct Decode_block* block){
}

void op_BEQ(struct CPU* CPU, struct Decode_block* block){
	unsigned int boolean;
	if(block->reg1->isData){
		if(block->reg2->isData)
			boolean = (block->reg1->data == block->reg2->data);
		else
			boolean = (block->reg1->data == *(Memory(GenAddress(block->reg2->data), CPU->job, "RAM", "r")));
	}
	else{
		if(block->reg2->isData)
			boolean = (*(Memory(GenAddress(block->reg1->data), CPU->job, "RAM", "r")) == block->reg2->data);
		else
			boolean = (*(Memory(GenAddress(block->reg1->data), CPU->job, "RAM", "r")) == *(Memory(GenAddress(block->reg2->data), CPU->job, "RAM", "r")));
	}
	
	if(boolean)
		CPU->program_counter = ((block->address / 4) - 1);
	else
		;
}

void op_BNE(struct CPU* CPU, struct Decode_block* block){
	unsigned int boolean;
	if(block->reg1->isData){
		if(block->reg2->isData)
			boolean = (block->reg1->data != block->reg2->data);
		else
			boolean = (block->reg1->data != *(Memory(GenAddress(block->reg2->data), CPU->job, "RAM", "r")));
	}
	else{
		if(block->reg2->isData)
			boolean = (*(Memory(GenAddress(block->reg1->data), CPU->job, "RAM", "r")) != block->reg2->data);
		else
			boolean = (*(Memory(GenAddress(block->reg1->data), CPU->job, "RAM", "r")) != *(Memory(GenAddress(block->reg2->data), CPU->job, "RAM", "r")));
	}
	
	if(boolean)
		CPU->program_counter = ((block->address / 4) - 1);
	else
		;
}

void op_BEZ(struct CPU* CPU, struct Decode_block* block){
}

void op_BNZ(struct CPU* CPU, struct Decode_block* block){
}

void op_BGZ(struct CPU* CPU, struct Decode_block* block){
}

void op_BLZ(struct CPU* CPU, struct Decode_block* block){
}
